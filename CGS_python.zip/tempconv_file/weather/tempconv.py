def fahr2cels(fahr): #화씨에서 섭씨로 변환
    cels = 5 / 9 * (fahr - 32)
    return(cels)

def cels2fahr(cels): #섭씨에서 화씨로 변환
    fahr = 9 / 5 * cels + 32
    return(fahr)
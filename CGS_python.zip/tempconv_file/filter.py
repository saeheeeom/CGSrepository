from weather.tempconv import fahr2cels #화씨에서 섭씨로 바꾸는 함수

import sys

for line in sys.stdin : #표준입력받은 파일을 한 행씩 처리
    line = int(line) #fahr2cels 함수에 넣기 위해 int 형식으로 바꾼다
    if (fahr2cels(line) > int(sys.argv[1]) \
        and fahr2cels(line) < int(sys.argv[2])) : #sys.argv[*]또한 str에서 int로
        print (line, fahr2cels(line))



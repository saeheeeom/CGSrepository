# unscramble.py

from PIL import Image

image = Image.open("scrambled.png")

pixels = image.load()
width = image.width     # width = 71
height = image.height   # height = 79


tile_height = 10
tile_width = 10

newimg = Image.new("RGB", (width, height), (255, 255, 255)) 
newpxl = newimg.load()

for h in range(int(height / tile_height)): 
    for w in range(int(width / tile_width)):
       stdR, stdG, stdB = pixels[10 * w, 10 * h]
       for th in range(tile_height):
            for tw in range(tile_width):
               r, g, b = pixels[w*tile_width + tw, h*tile_height + th]
               newpxl[10*stdR + tw, 10*stdG + th] = r, g, b
newimg.show()

newimg.save("unscrabled.png", "PNG")



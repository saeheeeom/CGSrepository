#과제2
temperatures = [62, 67, 73, 83, 87, 96, 100,\
     100, 97, 88, 84, 70] #매달 1일 maximum temp.

def fahr2cels(fahr): #화씨에서 섭씨로 바꾸는 함수
    cels = 5 / 9 * (fahr - 32)
    return(cels)


for t in temperatures: #t값의 범위에 따라 다르도록
    c=fahr2cels(t) #매 condition마다 함수를 쓰기 번거로워 미리 하나의 변수로 저장
    if c<=10 : print(t, c,'cool' )
    elif 10<c<=20 : print(t, c, 'mild')
    elif 20<c<=30 : print(t, c, 'warm')
    else : print(t, c, 'hot')
#과제2 (그리고 연습 1.6)
def fahr2cels(fahr): #화씨에서 섭씨로 변환
    cels = 5 / 9 * (fahr - 32)
    print(cels)
def cels2fahr(cels): #섭씨에서 화씨로 변환
    fahr = 9 / 5 * cels + 32
    print(fahr)


#밑의 내용은 연습 1.6에서 썼던 내용

import sys #sys모듈 가져오기

for line in sys.stdin: #표준입력될 경우
    line = float(line)
    cels =  fahr2cels(line)
    cels = str(cels)
    sys.stdout.write(cels) #표준출력은 섭씨로
    sys.stdout.write('\n') #이 위의 코드와 합칠수도 있음, write대신 print 쓸 수 있음.
# 2019-14505 엄세희
# 계수 리스트로 이차 방정식의 근 구하기
# poly.py - polynomials

from math import sqrt

# Polynomial Equation Solver
# coefficients : list of coefficients. for example [2, 3, 4] for 2x^2 + 3x + 4
# return list of solutions. for examaple [-1, 1] for x^2 - 1 = 0



# 방정식의 계수 리스트를 받아 근(실근/허근)을 돌려주는 함수 solve()
# 리스트의 길이에 따라 작동하도록 함수 정의

def solve(coefficients) :
    if len(coefficients) == 1 : # list의 길이가 1일 때
        print("Warning: undefined (there is no possible solution)")
        return float('nan')
        # 에러 메세지는 print, 결과값은 return


    elif len(coefficients) == 2 : # list의 길이가 2일 때
        b = coefficients[0]
        c = coefficients[1]
        if b == 0 :
            if c == 0 :
                print("Warning: indeterminate (0/0 form)")
                return float('nan')
            else :
                print("Warning: undefined (there is no possible solution)")
                return float('nan')
        else :
            return [(0 - c) / b]


    elif len(coefficients) == 3 : # list의 길이가 3일 때
        a = coefficients[0]
        b = coefficients[1]
        c = coefficients[2]
        if a == 0 :
            if b == 0 :
                if c == 0 :
                    print("Warning: indeterminate (0/0 form)")
                    return float('nan')
                else :
                    print("Warning: undefined (there is no possible solution)")
                    return float('nan')
            else :
                return [(0 - c) / b]
        else :
            if (b**2 - 4 * a * c) >= 0 : # 실근 존재할 때 
                sol1 = (-b + sqrt(b**2 - 4 * a * c)) / 2
                sol2 = (-b - sqrt(b**2 - 4 * a * c)) / 2
                if sol1 == sol2 :
                    return [sol1]
                else :
                    return [sol1, sol2] # 작동 예시의 순서 주의
            else : # 실근이 없을 때
                sol1 = (-b + (sqrt(0 - b**2 + 4 * a * c))*1j) / 2
                sol2 = (-b - (sqrt(0 - b**2 + 4 * a * c))*1j) / 2
                if sol1 == sol2 :
                    return [sol1]
                else :
                    return [sol1, sol2] # 작동 예시의 순서 주의
    

    else : # list의 길이가 4 이상일 때
        print("can't solve!", coefficients)
        return None
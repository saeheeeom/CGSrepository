# musicbox.py
#
# Usage :
#
# python musicbox.py merry-go-round.txt merry-go-round.wav
#
import sys
import wave
import math, struct
import random

from sinewave import tone # 같은 디렉토리에 있다고 가정

# http://pages.mtu.edu/~suits/notefreqs.html
# http://newt.phys.unsw.edu.au/jw/notes.html
# https://en.wikipedia.org/wiki/Musical_note
# http://blog.acipo.com/wave-generation-in-python/
# http://meettechniek.info/additional/additive-synthesis.html

notenum = {'do' : -9, 'dos' : -8, 'reb' : -8, 're' : -7, 'res' : -6, 'mib' : -6, 
    'mi' : -5, 'fa' : -4, 'fas' : -3, 'solb' : -3 , 'sol' : -2 , 'sols' : -2, 
    'rab' : -1, 'ra' : 0, 'ras' : 1, 'sib' : 1 , 'si' : 2 }

sampleRate = 8000.0 # hertz

sound = wave.open("mgr.wav", "w")
sound.setframerate(sampleRate)
sound.setnchannels(1)
sound.setsampwidth(2)



file = open('sample.txt')
firstline = file.readline()

tempodata = firstline.strip().split()
dur = float(tempodata[1]) / float(tempodata[3]) * 60

def datatype(x):
    try:
        float(x)
        return float
    except ValueError:
        return str


for line in file:
    musicline = line.strip().split()
    for onesound in musicline:
        note = ''
        intdat = ''
        if '.' in onesound:
            tmp = 1.5
        else:
            tmp = 1
        for i in onesound:
            if datatype(i) == str:
                if i != ':':
                    if i != '.':
                        note += i
            if datatype(i) == float:
                intdat += str(i)
        for key in notenum:
            if note == key:
                num = notenum[key]

        midi = ((12 * (float(intdat[0]) + 1) + 9) + num)
        freq = 440 * 2**((midi - 69) /12)
        amp = 0.5
        duration = dur / float(intdat[1]) * tmp
        ans = tone(freq, amp, duration)
        sound.writeframesraw(ans)

 

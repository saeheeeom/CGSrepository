# waveform.py
#
# Plot waveform
#
# Usage:
#
# python waveform.py sound.wav waveform.png
#
import sys
import wave
import matplotlib.pyplot

sound = wave.open("sori.wav", "r")


amps = []
for i in range(sound.getnframes()):
    b = sound.readframes(1)
    amp = int.from_bytes(b, byteorder='little', signed=True)
    amps.append(amp)

matplotlib.pyplot.plot(amps)
matplotlib.pyplot.show()

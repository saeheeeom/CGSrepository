# reverse.py
#
# Usage:
#
# python reverse.py orignal.wav reversed.wav
#
import sys
import wave
import random
import struct

sampleRate = 8000.0 # hertz

sound = wave.open("sori.wav", "r")
newsound = wave.open("reversed.wav", "w")
params = sound.getparams()
newsound.setnchannels(params.nchannels)
newsound.setsampwidth(params.sampwidth)
newsound.setframerate(params.framerate)


n = sound.getnframes()
for i in range(n):
    sound.setpos(n-i-1)
    newsound.writeframesraw(sound.readframes(1))

newsound.close()
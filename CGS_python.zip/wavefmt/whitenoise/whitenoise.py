# whitenoise.py
#
# Usage:
#
# python whitenoise.py amplitude duration whitenoise.wav
#
# eg) python whitenoise.py 0.5 10 whitenoise.wav
#
import sys
import wave
import random
import struct

sampleRate = 8000.0 # hertz

noise = wave.open("newwhitenoise.wav", "w")

noise.setframerate(sampleRate)
noise.setnchannels(1)
noise.setsampwidth(2)


duration = 5

n = int(duration*sampleRate)
data = bytearray(b'')
for _ in range(n):
    amp = random.randint(-32768, 32767)
    data.extend(struct.pack('<h', amp))

noise.writeframesraw(data)
noise.close()
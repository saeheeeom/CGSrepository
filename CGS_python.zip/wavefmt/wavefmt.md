# 오디오 처리

## WAV 파일 처리를 위한 준비

### 파일 열기

파이썬 표준 라이브러리의 `wave` 모듈을 이용하면 WAV 형식의 파일을 처리할 수 있다. 압축 형식은 지원하지 않는다. 다음과 같이 WAV 파일을 열 수 있다.

```python
import wave

sound = wave.open("sound.wav", "r")
```

### WAV 매개변수 읽기

WAV 파일은 앞부분에 몇가지 메타데이터를 포함하고 있으며 해당 오디오의 특성을 알려주는 매개변수 정보를 제공한다. 다음과 같이 WAV 파일의 매개변수들을 얻을 수 있다. 

```python
sound.getframerate()   #=> 48000
sound.getnframes()     #=> 44928
sound.getnchannels()   #=> 1
sound.getsampwidth()   #=> 2

```

다음과 같이 `getparams()` 메소드로 매개변수 전체를 얻을 수도 있다.

```python
params = soud.getparams()   
params.nchannels   #=> 1
params.sampwidth   #=> 2
params.framerate   #=> 48000
params.nframes     #=> 44928
```

우선 `framerate`는 샘플링 레이트(sampling rate)를 말한다. 이것은 초 단위 해상도이다. 보통 주파수(Hz)로 표현되며 1초에 샘플링을 하는 횟수에 해당한다. 사람의 말소리를 구별할 수 있는 수준의 8000Hz는 전화기에서 사용되는 샘플링 레이트이다. 오디오 CD에서는 44100Hz가 사용되고 전문 장비에서는 48000Hz가 표준으로 사용된다. 

그리고 `nframes`는 프레임의 개수이다. 오디오의 길이에 해당한다. `nframes`를 `framerate`로 나누면 오디오의 길이를 초 단위로 계산할 수 있다. 

다음으로 `nchannel`은 채널의 개수이다. 채널이 1개이면 모노 2개이면 스테레오에 해당한다. 

또 하나 중요한 것으로 `sampwidth`는 sample width, sample depth, bit width, bit depth 등으로도 불리는데 숫자 하나를 표현하는 데 사용하는 바이트 수를 말한다. 각 샘플의 해상도에 해당한다. 위 예에서는 2바이트 즉 16비트를 사용했음을 알 수 있다. 오디오 CD에서는 16비트, DVD에서는 24비트가 사용된다.

### WAV 데이터 읽기

그리고 다음과 같이 읽으려는 프레임의 수를 지정하여 데이터 값들을 읽을 수 있다. 읽은 값은 `bytes` 객체로 돌려준다. 위에서 sample width가 2이었으므로 한 프레임을 읽으면 2 바이트가 얻어진다. 따옴표 앞의 `b`는 이것이 `bytes` 객체임을 표현하는 것이다.

```python
sound.readframes(1)   #=> b'\x00\x00'
```

파일 전체를 한 프레임 씩 읽는다면 다음과 같이 할 수 있다.

```
for i in range(sound.getnframes()):
    frame = sound.readframes(1)
```

여기서 얻어지는 바이트 값들은 사실은 정수 값을 기록한 것이다. 정수 값을 바이트에 대응시키는 데에는 여러가지가 있는데 WAV 형식에서 Byte Order는 Little Endian이고 부호가 있는 값을 이용한다. 다음과 같이 바이트 값을 정수로 바꿀 수 있다.

```python
int.from_bytes(sound.readframes(1), byteorder='little', signed=True)
```

2바이트로는 $-32768$에서 $+32767$까지의 값을 표현할 수 있다. 정수 값을 바이트로 바꿀 때에는 `struct` 모듈을 이용하면 된다. 형식에서 `h`는 2바이트의 부호가 있는 정수를 뜻하고 `<`는 Little Endian을 뜻한다.

```python
import struct

struct.pack('<h', 5)                                           #=> b'\x05\x00'
int.from_bytes(b'\x05\x00', byteorder='little', signed=True)   #=> 5
```

## 파형 그래프 그리기

WAV 형식은 일정한 시간 간격으로 소리의 진폭을 순서대로 기록한 것이기 때문에 그대로 그래프로 그리면 파형을 볼 수 있다. `matplotlib` 패키지를 이용하여 파형 그래프를 그려보자.

```python
# waveform.py

import wave
import matplotlib.pyplot

sound = wave.open("sori.wav", "r")

amps = []
for i in range(sound.getnframes()):
    b = sound.readframes(1)
    amp = int.from_bytes(b, byteorder='little', signed=True)
    amps.append(amp)

matplotlib.pyplot.plot(amps)
matplotlib.pyplot.show()
```

다음과 같은 결과를 얻을 수 있다.

![waveform](waveform/waveform.png)

파형 그래프에서 가로축은 시간이고 세로축은 진폭이지만 위 그래프에서는 단순히 가로축은 프레임의 번호 세로축은 각 프레임에 들어있는 정수값을 이용하였다. 

## 오디오 변형하기

### 거꾸로 재생

오디오 파일을 읽어서 거꾸로 재생한 파일을 생성해 보자. 우선 다음과 같이 원본 오디오를 읽고 그와 동일한 매개변수를 가진 새로운 오디오 파일을 생성하자.

```python
# reverse.py

import wave
import struct

sound = wave.open("orignal.wav", "r")
newsound = wave.open("reversed.wav", "w")
params = sound.getparams()
newsound.setnchannels(params.nchannels)
newsound.setsampwidth(params.sampwidth)
newsound.setframerate(params.framerate)

```

소리의 순서를 뒤집는 것은 간단하다. 샘플 프레임의 순서를 뒤집어서 새로운 파일에 저장하면 된다. 예를 들어, 다음과 같이 할 수 있다.

```python
n = sound.getnframes()
for i in range(n):
    sound.setpos(n-i-1)
    newsound.writeframesraw(sound.readframes(1))

newsound.close()
```

### 느리게 재생

오디오 파일을 느리게 재생하는 파일을 생성해 보자. 원본과 같은 매개변수를 가진 파일을 생성하는 것은 거꾸로 재생 예제와 동일한다.

```python
n = sound.getnframes()
for i in range(n):
    frame = sound.readframes(1)
    newsound.writeframesraw(frame)
    newsound.writeframesraw(frame)

newsound.close()
```



## 오디오 생성하기

### 백색 소음

이번에는 WAV 파일을 생성해 보자. `wave.open()`으로 파일을 연 후에 우선 매개변수를 지정해 주어야 한다. 예를 들면 다음과 같이 8000Hz 16 비트 모노로 지정해 보자.  백색 소음을 생성하기 위하여 `random` 모듈도 필요하다.

```python
# whitenoise.py

import wave
import random

noise = wave.open("whitenoise.wav", "w")

sampleRate = 8000
noise.setframerate(sampleRate)
noise.setnchannels(1)
noise.setsampwidth(2)
```

이제 이 WAV 파일에 백색 소음을 생성하여 저장해 보자. 우선 생성하고자 하는 사운드의 길이를 정해야 한다. 만약 5초 길이의 소리를 생성하고 싶다면 8000Hz이므로 생성해야 할 프레임의 개수는 $5\times8000 = 40000$개가 된다. 16비트 사운드이므로 $-32768$에서 $+32767$까지의  정수 중 임의로 하나를 고른 후에 프레임에 추가한다. 다음과 같다.

```python
duration = 5

n = int(duration*sampleRate)
data = bytearray(b'')
for _ in range(n):
    amp = random.randint(-32768, 32767)
    data.extend(struct.pack('<h', amp))
```

이제 이렇게 생성된 데이터를 WAV 파일에 기록해 보자.

```python
noise.writeframesraw(data)
noise.close()
```

### 순수한 톤

이번에는 삼각함수를 이용하여 특정한 음높이의 톤을 생성해 보자. 톤을 생성할 때에는 사인 함수, 즉 사인파를 이용할 수 있다. 특정한 음을 생성하기 위해서는 소리의 크기와 주파수가 필요하다. 소리의 크기를 $A$, 주파수를 $f$라고 하면 시간 $t$에 대해  사인파는 다음 식을 이용해 얻을 수 있다.
$$
y(t) = A \sin (2\pi f t)
$$
소리의 크기 $A$는 16비트 오디오라면 $-32768$에서 $+32767$까지의  정수로 지정한다. 주파수 $f$는 헤르치(Hz) 단위의 숫자로 지정한다. 시점 $t$에 해당하는 위치는 샘플링 레이트를 $r$라고 하고 샘플의 위치를 $i$라고 하면 $i/r$로 얻을 수 있다. 소리의 길이는 프레임의 개수로 조절할 수 있다. WAV 파일을 만들고 데이터를 저장하는 것은 백색 소음 예제와 동일하다.

기본 세팅이 다음과 같다면

```python
# sinewave.py

frequency = 440   # Hz
amplitude = 0.5   # 0 to 1
duration = 3      # seconds

framerate = 8000
sampwidth = 2
maxVolume = 2**(sampwidth*8 - 1) - 1

volume = int(amplitude * maxVolume)
n = int(duration * framerate)   # number of frames
```

사인파로 순수한 톤은 다음과 같이 생성할 수 있다.

```
packed = bytearray(b'')
for i in range(n) :
    t = i / sampleRate
    y = int(volume * math.sin(2*math.pi * frequency * t))
    packed.extend(struct.pack('<h', int(y)))
```



이렇게 특정한 톤을 생성하는 함수를 다음과 같이 작성하여 사용할 수 있을 것이다.

```python
def tone(frequency, amplitude, duration, framerate, sampwidth):
    
```



## 음악

### 음표

음악에서 A440 또는 A4는 피아노의 한 가운데 있는 도(가온다)의 오른쪽에 있는 라 음을 가리키는 것으로  음 높이를 맞추는 표준음으로 사용된다.

- https://en.wikipedia.org/wiki/A440_(pitch_standard)

음표를 도(C), C#/D♭, 레(D), E♭/D#, 미(E), 파(F), F#/G♭, 솔(G), A♭/G#, 라(A), B♭/A#, 시(B)로 표기하고 옥타브를 0, 1, 2. 3 등으로 표기하여 피아노 건반 위의 음들을 `C4`,` A4` 등으로 나타낼 수 있다. MIDI (Musical Instrument Digital Interface)에서는 가장 낮은  `C-1`을 0번으로 하여 순서대로 일련번호를 붙여 놓고 있다.

- https://en.wikipedia.org/wiki/Scientific_pitch_notation

특정 음의 주파수는 MIDI 번호를 $m$이라고 했을 때 다음 공식으로 구할 수 있다.
$$
440 \times 2^{(m-69)/12}
$$
예를 들어, 가온다(C4)의 MIDI 번호는 60번이고 주파수는 다음과 같이 구할 수 있다.

```python
m = 60
freq = 440 * 2**((m - 69)/12)  #=> 261.6255653005986
```

이제 앞서 작성한 `tone()` 함수를 이용하여 MIDI 번호가 주어지면 해당하는 음을 생성할 수 있을 것이다. 예를 들어, 다음과 같이 적절한 함수를 작성하여 음표를 해당하는 소리로 바꿀 수 있을 것이다.

```python
note = 'C4'
amp = 0.5
dur = 0.5

midi = note2midi(note)     # convert musical note to midi number
freq = midi2freq(midi)     # convert midi number to frequency
tone(freq, amp, dur)
```

### 악보

악보를 전산적인 형태로 표현하는 방법을 생각해 보자. 컴퓨터로 악보를 그릴 수 있게 해 주는 오픈 소스 소프웨어 중의 하나인 LilyPond에서 음표를 표현하는 방법의 예를 다음 페이지에서 참조할 수 있다.

- [http://lilypond.org/doc/v2.18/Documentation/notation/writing-pitches#note-names-in-other-languages](http://lilypond.org/doc/v2.18/Documentation/notation/writing-pitches#note-names-in-other-languages)

우리도 이와 유사하게 다음과 같은 형식으로 음악을 표시한다고 생각해 보자.

```
tempo 4 = 120
mi4:4 ra4:4 do5:4      mi5:2 mi5:4          re5:4 do5:4 si4:4           do5:2.    
ra4:4 do5:4 mi5:4      ra5:2 ra5:4          ra5:4 si5:4 sol5:8 fa5:8    sol5:2.
si4:4 mi5:4 sol5:4     si5:2 ra5:4          sol5:4 fas5:4 sol5:4        ra5:2 sol5:4
fas5:2 mi5:4           mi5:4 re5:4 do5:4    si4:4 dos5:4. res5:8        mi5:2.
mi4:4 ra4:4 do5:4      mi5:2 mi5:4          re5:4 do5:4 si4:4           do5:2.
```

맨 첫줄의 `tempo 4 = 120`은 4분음표를 1분에 120개 연주하라는 뜻이다. 즉, 4분음표 하나가 0.5초에 해당한다. 음은 do, re, mi, fa, sol, ra, si로 표기하였고 올림(#)과 내림(♭)은 각각 `s`와 `b`를 덧붙였다. 옥타브는 음 이름에 이어 숫자로 붙였다.  콜론 뒤에는 박자를 표시하였다. `4`는 4분음표, `8`은 8분음표이고 `4.`은 점4분음표이다. 위 예의 경우에 4분음표는 0.5초, 8분음표는 0.25초, 점4분음표는 0.75초 동안 연주하게 된다.

위와 같이 텍스트 파일로 악보가 주어졌을 때 오디오 파일을 생성하는 프로그램을 작성해 보자.








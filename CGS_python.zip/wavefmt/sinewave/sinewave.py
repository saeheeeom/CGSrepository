# sinewave.py
#
# Generate sinewave
#
# set default framerate = 8000, sampwidth = 2
#
# Usage:
#
# python sinewave.py frequency amplitude duration sinewave.wav
#
# eg) python sinewave.py 440 0.5 3 sinewave.wav
#
#
import sys
import wave 
import math, struct

# frequency = 440  # Hz
# amplitude = 0.5  # 0 to 1 
# duration = 3     # seconds
# framerate = 8000
# sampwidth = 2

def tone(frequency, amplitude, duration, framerate=8000, sampwidth=2):
    noise = wave.open("nsinewave.wav", "w")

    noise.setframerate(framerate)
    noise.setnchannels(1)
    noise.setsampwidth(2)

    maxVolume = 2**(sampwidth*8 - 1) - 1
    volume = int(amplitude*maxVolume)
    n = int(duration*framerate)

    packed = bytearray(b'')
    for i in range(n) :
        t = i / framerate
        y = int(volume * math.sin(2*math.pi * frequency * t))
        packed.extend(struct.pack('<h', int(y)))
    noise.writeframesraw(packed)
    noise.close()
    
tone(440, 0.5, 3, 8000, 2)

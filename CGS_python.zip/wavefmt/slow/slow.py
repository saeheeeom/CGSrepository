# slow.py
# 2019-14505 엄세희
# Generates 0.5x slowed down sound
#
# Usage:
#
# python slow.py orignal.wav slow.wav 
#
import sys
import wave
import struct

sampleRate = 8000.0 # hertz

sound = wave.open("sori.wav", "r")
newsound = wave.open("slow.wav", "w")
params = sound.getparams()
newsound.setnchannels(params.nchannels)
newsound.setsampwidth(params.sampwidth)
newsound.setframerate(params.framerate)


n = sound.getnframes()
for i in range(n):
    frame = sound.readframes(1)
    newsound.writeframesraw(frame)
    newsound.writeframesraw(frame)

newsound.close()
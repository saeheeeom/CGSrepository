# physics.py
# 2019-14505 엄세희


# mass1 : mass of the object 1 (unit: kg)
# mass2 : mass of the object 2 (unit: kg)
# distance : distance between the centers (unit: m)

# 두 물체 사이 중력 계산하는 함수 정의
def force(mass1, mass2, distance): #간단한 변수로 정리
    m_1 = mass1
    m_2 = mass2
    r = distance
    G = 6.67408e-11
    F = G * (m_1 * m_2) / (r**2)
    return F



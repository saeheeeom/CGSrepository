# solve.py
# 2019-14505 엄세희

# 수식구현 01 : 뉴턴의 만유인력의 법칙

from physics import force

# calculate prob1 : 지구와 달 사이의 중력 계산하기

def answer01():
    mEarth = 5.97e24   # mEarth : 지구의 질량 (단위: kg)
    mMoon = 7.3e22     # mMoon : 달의 질량 (단위: kg)
    r = 3.84e8         # r : 지구와 달 사이 평균 거리 (단위: m)
    ans = force(mEarth, mMoon, r)
    return ans


# calculate prob2 : 지구와 사과 사이의 중력 계산하기

def answer02():
    mEarth = 5.97e24    # mEarth : 지구의 질량 (단위: kg)
    mApple = 2.40e-1    # mApple : 사과의 질량 (단위: kg)
    r = 6.4e6           # r : 지구와 사과 사이 거리 (단위: m)
    ans = force(mEarth, mApple, r)
    return ans



# 수식구현 02 : 미래가치

from finance import fv

# calculate prob3 : 월복리 이자와 연복리 이자의 차이 계산하기

def answer03():
    pv = 1.0e7                 # 현재가치 (단위 : 원)
    r1 = 2.5e-2                # 연복리 이자율 
    n1 = 5                     # 연복리 기간
    fv1 = fv(r1, n1, pv)
    interestYear = fv1 - pv    # 연복리 이자 

    r2 = (2.5 / 12) * 1.0e-2   # 월복리 이자율
    n2 = 60                    # 월복리 기간
    fv2 = fv(r2, n2, pv)
    interestMonth = fv2 - pv   # 월복리 이자 

    # 월복리 이자와 연복리 이자의 차이의 절댓값
    ans = abs(interestYear - interestMonth)  
    return ans
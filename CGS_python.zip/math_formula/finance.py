# finance.py
# finance functions
# 2019-14505 엄세희


# rate : interest rate per period
# nper : total number of payment periods in the investment
# pv : present value

# 현재가치를 미래가치로 바꾸는 함수 정의
def fv(rate, nper, pv): #간단한 변수로 정리
    r = rate
    n = nper
    fv = pv * ((1 + r) ** n)
    return fv



# dataproc.py - data processing exercise
# 2019-14505
# 엄세희




# (Example 3.2)
# sum numbers in numbers.txt
# 숫자가 한 행에 하나 있는 경우

file = open("data/numbers.txt")

total = 0
for line in file:
    x = float(line)
    total += x

file.close()






# (Example 3.8)
# sum numbers in mat.txt
# 숫자가 한 행에 여러개 있는 경우

file = open("data/mat.txt")

total = 0
for line in file :
    toks = line.split()
    for tok in toks :
        x = float(tok)
        total += x

file.close()





#
# sum the 3rd column in table.txt
# 한 행에 여러 정보가 들어있는 table
# 첫번째 행은 해당되지 않음

file = open("data/table.txt")

firstline = file.readline()
colnames = firstline.split()

# loop over rows (from 2nd row to end)

total = 0

for line in file :
    name, qty, mrp = line.split()
    mrp = float(mrp)
    total += mrp

file.close()






#
# row sums in mat.txt
# matrix형에서 각 행의 total 구하기

file = open("data/mat.txt")

rowsums = []

for line in file :
    toks = line.split()
    
    total = 0.0
    for tok in toks :
        x = float(tok)
        total += x
    
    rowsums.append(total)
    
file.close()






#
# count g's in dna
#

dna = 'gtgcgactccttctatgagtagaccacacctt'

count = 0
for base in dna :
    if base == 'g' :
        count += 1






#
# count apple's in names.txt
#

file = open("data/names.txt")

count = 0
for line in file:
    word = line.strip()

    if word == 'apple' :
        count +=1


file.close()






#
# count apple's in text.txt
#

count = 0

file = open('data/text.txt')

for line in file :
    words = line.split()
    for word in words :
        if word == 'apple' :
            count += 1


file.close()






#
# compute letter frequency in dna.txt
#

# 방법1: 텍스트파일에 알파벳만 있다는 것을 알 경우
# 정답 출력 O

file = open("data/dna.txt")

text = []
for line in file :
    line = line.strip()
    for base in line :
        text.append(base)

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 
'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 
'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
print(alphabet)

dnacount = []


for letter in alphabet :
    count = 0
    for dna in text :
        if dna == letter :
            count += 1
    if count > 0 :
        dnacount.append([letter, count])


file.close()





# 방법2 : 텍스트에 알파벳만 있다는 것을 모르는 경우
# 정답 출력 X
# 반복문을 이용해서 1. 리스트에 있는 문자 개수 센 뒤 2. 해당 문자 제외 리스트 다시 만들기
# 왜 안되는지 모르겠습니다


file = open("data/dna.txt")

text = []
for line in file :
    line = line.strip()
    for base in line :
        text.append(base)

lastbase = 'g'
newtext = text
for x in text :

    count = 0
    if x == lastbase :
        for dna in newtext :
            newtext = []
            if dna == lastbase :
                count += 1
            if dna != lastbase :
                newtext.append(dna)
        dnacount.append([x, count])

    if x != lastbase :
        lastbase = x



file.close()
